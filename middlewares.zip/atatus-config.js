// atatus-config.js
module.exports = {
	licenseKey: "lic_apm_1f950d952bfd494b9f60b20bb6687d69",
	appName: "scheduler",
};